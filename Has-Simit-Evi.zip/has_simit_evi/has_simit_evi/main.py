import pygame
pygame.font.init()

win = pygame.display.set_mode((800,500))
uilayer = pygame.display.set_mode((800,500))
pygame.display.set_caption("Has Simit Evi")

run=True
font=pygame.font.SysFont("monospace",25)
dükkanpos=[(70, 143), (101, 128), (95, 156), (143, 153), (192, 170), (210, 181), (156, 208), (66, 205), (107, 224), (113, 273), (78, 286), (106, 321), (120, 359), (155, 329), (186, 342), (159, 287), (227, 367), (223, 321), (209, 283), (171, 252), (193, 212), (229, 237), (293, 229), (254, 192), (238, 173), (266, 157), (291, 136), (329, 141), (293, 168), (380, 139), (366, 192), (326, 186), (334, 233), (350, 257), (286, 315), (307, 369), (338, 391), (371, 328), (335, 305), (372, 284), (411, 293), (389, 239), (435, 206), (403, 194), (408, 164), (470, 185), (464, 247), (451, 328), (399, 348), (425, 363), (425, 404), (467, 366), (454, 383), (531, 359), (505, 332), (492, 290), (525, 237), (509, 190), (540, 206), (554, 176), (595, 167), (633, 155), (669, 161), (680, 192), (622, 214), (567, 200), (545, 256), (598, 263), (534, 286), (584, 313), (598, 347), (622, 322), (652, 316), (671, 337), (714, 284), (729, 331), (682, 228), (650, 289), (156, 179),(632, 267), (717, 209)]
positions=[]
buttons=[]
dükkanlar=[]

yiyecekler=["simit","tost","poğaça","menemen"]
yiyecektier=0
yiyecekfiyat=500
yiyecektalep=50
yfo=yiyecekfiyat
yto=yiyecektalep

içecekler=["çay","kahve"]
içecektier=0
içecekfiyat=500
içecektalep=50
içecekstart=3

tree=False
fiyat=1000
para=100000
arz=0
talep=0
class Türkiye(pygame.sprite.Sprite):
    def __init__(self,pos,path):
        super().__init__()
        self.image = pygame.image.load(path)
        self.rect = self.image.get_rect()
        self.rect.center=[pos[0],pos[1]]

class shop(pygame.sprite.Sprite):
    def __init__(self,pos,path):
        super().__init__()
        self.image = pygame.image.load(path)
        self.image = pygame.transform.scale(self.image, (20, 20))
        self.rect = self.image.get_rect()
        self.rect.center=[pos[0],pos[1]]
    def die(self):
        self.kill()

class sprite(pygame.sprite.Sprite):
    colorx=(0,0,0)
    def __init__(self,pos,width,height,color):
        super().__init__()
        self.image = pygame.Surface([width,height])
        self.pos=pos
        self.width=width
        self.height=height
        colorx=color
        self.image.fill(colorx)
        self.rect = self.image.get_rect()
        self.rect.center=[pos[0],pos[1]]
    def colorchange(self,newcolor):
        colorx=newcolor
        self.image = pygame.Surface([self.width,self.height])
        self.image.fill(colorx)
        self.rect = self.image.get_rect()
        self.rect.center=[self.pos[0],self.pos[1]]

class item(pygame.sprite.Sprite):
    def __init__(self,pos,path,name,tur=0):
        super().__init__()
        self.pos=pos
        self.name=name
        self.tur=tur
        if(self.name!=""):
            if tur==0:
                try:
                    self.index=yiyecekler.index(self.name)
                except:
                    print(self.tur)
            else:
                self.index = içecekler.index(self.name)
        else:
            self.index=0
        self.talep=int(yto*3**self.index)
        self.fiyat = int(yfo * 4 ** self.index)
        self.image = pygame.image.load(path)
        self.image = pygame.transform.scale(self.image, (30, 30))
        self.rect = self.image.get_rect()
        self.rect.center=[pos[0],pos[1]]
        self.image.fill((0,0,0),self.rect)

tr= Türkiye((400,270),"türkiye.png")
currentitem=item((0,0),"placeholder.png","")
sprites=pygame.sprite.Group()
sprites.add((tr))

yeşil=(0,255,0)
gri=(80,80,80)
yiyecekY=260

for i in dükkanpos:
    sprites.add(shop(i, "point.png"))
while run:
    pygame.time.delay(10)
    win.fill((0,0,0))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=0
        if event.type==pygame.MOUSEBUTTONDOWN:
            #dükkan pozisyonlarını belirlemek için kullanılan kod
            #sprites.add(sprite(pygame.mouse.get_pos(),"point.png"))
            #positions.append(pygame.mouse.get_pos())
            #print(positions)
            if pygame.mouse.get_pressed()[0]:
                for i in sprites:
                    if i.__class__==Türkiye or i.__class__==sprite:
                        continue
                    else:
                        if i.__class__==shop:
                            if i.rect.collidepoint(pygame.mouse.get_pos()) and para>fiyat and not tree:
                                i.image=pygame.transform.scale(pygame.image.load("tik.png"),(20,20))
                                para-=fiyat
                                fiyat*=1.5
                                arz+=50
                                fiyat=int(fiyat)
                                print("clicked")
                        elif i.__class__==item:
                            if i.rect.collidepoint(pygame.mouse.get_pos()):
                                if i.tur==0:
                                    if yiyecektier==yiyecekler.index(i.name) and yiyecekfiyat<=para:
                                        para-=i.fiyat
                                        buttons[yiyecekler.index(i.name)*2].colorchange(yeşil)
                                        try:
                                            buttons[yiyecekler.index(i.name)*2+1].colorchange(yeşil)
                                        except:
                                            print("hayır")
                                        sprites.update()
                                        talep+=yiyecektalep
                                        yiyecektier+=1
                                        yiyecektalep*=3
                                        yiyecekfiyat*=4
                                        print("alındı")
                                elif i.tur==1 and yiyecektier>=3:
                                    if içecektier == içecekler.index(i.name) and içecekfiyat <= para and yiyecektier>=3:
                                        para-=i.fiyat
                                        içecektier+=1
                                        talep+=i.talep
                                        print("içecek")

        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_TAB:
                tree=not tree
                if tree:
                    treesprite=sprite((500,300),1000,400,(0,0,0))
                    sprites.add(treesprite)
                    items=[]
                    buttons=[]
                    transitions=[]
                    a=0
                    for i in range(len(yiyecekler)+len(içecekler)):
                        c=yeşil
                        y=[200+100*i,yiyecekY]
                        if(i>=yiyecektier):
                            c=gri
                        if i<len(yiyecekler):
                            buttons.append(sprite((y[0], y[1]), 40, 40, c))
                            sprites.add(buttons[len(buttons) - 1])
                            if i!=len(yiyecekler)-1:
                                buttons.append(sprite((250+100*i,yiyecekY),60,10,c))
                                sprites.add(buttons[len(buttons)-1])
                        if i<=len(yiyecekler)-1:
                            items.append(item((200+100*i,260),"placeholder.png",yiyecekler[i]))
                            sprites.add(items[len(items)-1])
                        elif i>len(yiyecekler)-1:
                            items.append(item((200+100*(içecekstart-1)+(i-len(yiyecekler))*100,160),"placeholder.png",içecekler[i-len(yiyecekler)],1))
                            sprites.add(items[len(items)-1])
                        a+=1
                else:
                    treesprite.kill()
                    for i in buttons:
                        i.kill()
                    for i in items:
                        i.kill()
        if tree:
            hover=False
            for i in items:
                if i.rect.collidepoint(pygame.mouse.get_pos()):
                    currentitem=i
                    hover=True
            if not hover:
                currentitem=item((0,0),"placeholder.png","")
        else:
            currentitem = item((0, 0), "placeholder.png", "")

    paratxt = font.render(("para: "+str(para)+"TL"),1,(255,255,255))
    itemtxt = font.render(currentitem.name, 1, (255, 255, 255))
    treetaleptxt=font.render("+"+str(currentitem.talep)+" talep", 1, (255, 255, 255))
    treefiyattxt = font.render("-" + str(currentitem.fiyat) + " TL", 1, (255, 255, 255))
    arztxt = font.render(("arz: "+str(arz)+"TL/sn"),1,(255,255,255))
    taleptxt = font.render(("talep: " + str(talep) + "TL/sn"), 1, (255, 255, 255))
    fiyattxt = font.render(("dükkan fiyatı: " + str(fiyat) + "TL"), 1, (255, 255, 255))
    win.blit(paratxt,(0,0))
    win.blit(arztxt, (0, 30))
    win.blit(taleptxt, (0, 60))
    win.blit(fiyattxt,(0,450))

    sprites.draw(win)

    win.blit(itemtxt, (currentitem.pos[0]-len(currentitem.name)*7, currentitem.pos[1]-60))
    if currentitem.name!="":
        win.blit(itemtxt, (10, 400))
        win.blit(treetaleptxt,(10,430))
        win.blit(treefiyattxt, (10, 450))

    pygame.display.flip()

pygame.quit()